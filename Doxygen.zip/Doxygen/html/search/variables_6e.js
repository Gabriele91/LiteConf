var searchData=
[
  ['name',['name',['../struct_lite_conf_1_1_value.html#a363e4cf8eb8502bd4ef038a735031855',1,'LiteConf::Value::name()'],['../struct_lite_conf_1_1_block.html#aba53d37dd9f0757eea789b25cd9fc7e6',1,'LiteConf::Block::name()']]]
];
