var searchData=
[
  ['value',['Value',['../struct_lite_conf_1_1_value.html#abc2a5a2e6484fac66dae2539cc955667',1,'LiteConf::Value::Value()'],['../struct_lite_conf_1_1_value.html#a77b5aa6777310d32b61690c2ac81bbf6',1,'LiteConf::Value::Value(const std::string &amp;name, float value)'],['../struct_lite_conf_1_1_value.html#a952be360ae148668ef8528f7a66429cd',1,'LiteConf::Value::Value(const std::string &amp;name, const std::string &amp;value)']]]
];
